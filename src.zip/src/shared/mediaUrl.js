export function pickMediaUrl(...candidates) {
  for (const url of candidates) {
    if (!url) continue;
    if (url.includes("127.0.0.1") || url.includes("localhost")) continue;
    return url;
  }
  return candidates.find(Boolean) || null;
}