import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";

const resources = {
  en: {
    translation: {
      nav: {
        home: "Home",
        brand_name: "Zukhruf",
        gallery: "Gallery",
        projects: "Projects",
        simulator: "Simulator",
        login: "Login",
        register: "Register",
      },
      home: {
        hero_badge: "Smart CNC Toolpath Generator",
        hero_title_1: "The Art of Precision in",
        hero_title_2: "Smart Manufacturing",
        hero_desc:
          "Turn your engineering imagination into tangible mechanical reality. Zukhruf provides the most precise and fast processing tools to generate G-Code toolpaths with a single click.",
        btn_start: "Start Processing",
        btn_explore: "Explore Gallery",

        feature_offset_title: "Adaptive Offsetting",
        feature_offset_desc:
          "Toolpaths follow the true width of your ornament — wide areas get more passes, narrow areas stay safe.",
        feature_arcs_title: "Clean Arc Paths",
        feature_arcs_desc:
          "Curves are fitted to G2/G3 arcs instead of dense zigzag G1 segments.",
        feature_coverage_title: "Coverage Preview",
        feature_coverage_desc:
          "Check tool reach before you carve, and switch diameter when thin details need it.",

        steps_title_1: "How it",
        steps_title_2: "Works?",
        steps_subtitle:
          "Three simple steps between your image and a machine-ready toolpath.",
        step2_title: "AI Processing",
        step2_desc: "Our algorithms analyze and convert the image to vector.",
        step3_title: "Generate G-Code",
        step3_desc: "Download the ready-to-use CNC toolpath.",

        patterns_title_1: "Public",
        patterns_title_2: "Patterns",
        patterns_desc:
          "Professional and consistent designs from the community.",
        btn_view_all: "View All Patterns",
        pattern_badge: "PATTERN",
        no_description: "No description",
        user: "User",
        cta_title: "Ready to Transform Your Designs?",
        cta_desc:
          "Join thousands of makers and start generating CNC toolpaths in seconds.",
        btn_create_account: "Create Your Project Now",
      },
      auth: {
        login_title: "Welcome Back!",
        login_subtitle: "Please enter your details to sign in.",
        username: "Username",
        username_placeholder: "Enter your username",
        password: "Password",
        password_placeholder: "Enter your password",
        logging_in: "Logging in...",
        login_btn: "Login",
        no_account: "Don't have an account?",
        create_account_link: "Create a new account",

        register_title: "Create Account",
        register_subtitle: "Sign up now to start creating your CNC projects.",
        choose_username: "Choose a username",
        email: "Email Address",
        optional: "(Optional)",
        email_placeholder: "Enter your email",
        create_password: "Create a password",
        confirm_password: "Confirm Password",
        reenter_password: "Re-enter your password",
        creating_account: "Creating account...",
        register_btn: "Register Now",
        has_account: "Already have an account?",
        login_link: "Login here",

        hero_desc:
          "The fastest and most precise platform to convert designs into machine-ready CNC toolpaths.",
        copyright: "© 2026 Zukhruf CNC Hub. All rights reserved.",
        login_hero_title: "Turn Your Imagination",
        login_hero_subtitle: "Into Reality",
        login_feat_1: "Ultra-fast G-Code processing",
        login_feat_2: "Integrated project management",
        login_feat_3: "High precision for all CNC machines",

        register_hero_title: "Start Your Journey",
        register_hero_subtitle: "Into Smart Mfg",
        register_feat_1: "Instant G-Code generation",
        register_feat_2: "Public pattern library",
        register_feat_3: "Advanced & easy control interface",
      },
      footer: {
        desc: "The ultimate engineering platform for image processing and G-Code generation. Built for precision and creators.",
        quick_links: "Quick Links",
        link_home: "Home Page",
        link_gallery: "Explore Gallery",
        link_new_project: "Create New Project",
        link_projects: "My Projects",
        connect: "Connect With Us",
        connect_desc: "Have questions or feedback? Feel free to reach out.",
        copyright: "© 2026 Zukhruf CNC Hub. All rights reserved.",
      },
      gallery: {
        title_1: "My",
        title_2: "Gallery",
        subtitle: "Manage your uploaded images and patterns.",
        btn_upload: "Upload New",
        filter_all: "All Images",
        filter_patterns: "My Patterns",
        no_images_title: "No images found",
        no_images_desc: "You haven't uploaded any {{type}} yet.",
        type_patterns: "patterns",
        type_images: "images",
        loading: "Loading...",
        btn_load_more: "Load More Images",
        no_description: "No description",
        uploaded_by: "Uploaded by",
        btn_delete: "Delete",
        confirm_delete: "Are you sure you want to delete this image?",
        btn_delete_all: "Delete All",
        deleting_all: "Deleting...",
        confirm_delete_all:
          "Are you sure you want to permanently delete ALL your images and patterns? This cannot be undone.",
        badge_pattern: "Pattern",
        view_details: "View Details",
        generate_gcode: "Generate G-Code",
        delete_image: "Delete Image",
        id_prefix: "ID:",
      },
      projects: {
        title_1: "My",
        title_2: "Projects",
        subtitle: "View and manage your generated CNC toolpaths.",
        btn_new: "New Project",
        no_projects_title: "No projects yet",
        no_projects_desc: "You haven't created any CNC projects.",
        loading: "Loading...",
        btn_load_more: "Load More Projects",
        badge_completed: "COMPLETED",
        no_description: "No description",
        dimensions: "Dimensions",
        depth: "Depth",
        est_time: "Est. Time",
        minutes: "mins",
        btn_delete: "Delete Project",
        confirm_delete: "Are you sure you want to delete this project?",
        status_completed: "COMPLETED",
        status_unknown: "UNKNOWN",
        status_failed: "FAILED",
        status_processing_badge: "PROCESSING",
        dim: "Dim:",
        view_details: "View Details",
        get_nc: "Download .nc",
        pending: "Pending",
        delete_project: "Delete Project",
      },
      new_project_sidebar: {
        drag_drop: "Drag & Drop Image",
        or: "or",
        browse: "Browse Files",
          file_too_large: "Image size exceeds 15 MB. Please choose an image smaller than 15 MB.",
        step1_title: "Step 1: Image Details",
        image_title: "Image Title",
        description: "Description",
        save_pattern: "Save as Public Pattern",
        uploading: "UPLOADING...",
        upload_btn: "UPLOAD TO SERVER",
        step2_title: "Step 2: CNC Setup",
        width_x: "Width (mm)",
        height_y: "Height (mm)",
        min_dimension_error: "Must be at least {{min}} mm",
        tool_diameter: "Tool Diameter (mm)",
        tool_diameter_hint:
          "Smaller bit = finer detail but slower. The engine may auto-switch to a wider bit if this one can't fully reach the design.",
        analyzing: "ANALYZING IMAGE...",
        preview_ai: "PREVIEW AI PROCESSING",
        checking_coverage: "CHECKING COVERAGE...",
        creating: "CREATING...",
        project_created: "PROJECT CREATED",
        create_project: "CREATE PROJECT",
        cut_depth: "Cut Depth (Z)",
cut_depth_hint: "Negative value = depth into the material (e.g. -3 mm).",
safe_z: "Safe Height (Z)",
feed_rate: "Feed Rate",
plunge_rate: "Plunge Rate",
spindle_speed: "Spindle Speed",
machine_hourly_rate: "Machine Hourly Rate",
      },
confirm_delete_modal: {
  title: "Confirm Deletion",
  message: "Are you sure you want to delete this item? This action cannot be undone.",
  message_with_name: "Are you sure you want to delete \"{{name}}\"? This action cannot be undone.",
  warning: "This action is permanent and cannot be reversed.",
  confirm: "Yes, Delete",
  cancel: "Cancel",
  close: "Close",
},
      image_details: {
        badge_pattern: "Pattern",
        uploaded_on: "Uploaded on:",
        description: "Description",
        no_description:
          "No description provided for this image. You can proceed to generate CNC toolpaths directly.",
        actions: "Actions",
        btn_start_project: "Start CNC Project",
        btn_starting_project: "Starting Project...",
        error_start_project: "Failed to start CNC project. Please try again.",
        btn_delete_image: "Delete Image",
        default_alt: "Image",
        confirm_delete: "Are you sure you want to delete this image?",
      },
      coverage_modal: {
  title: "Tool Diameter Check",
  current_tool: "Your tool",
  suggested_tool: "Suggested",
  coverage_percent: "Coverage",
  keep_current: "Keep {{mm}}mm",
  switch_to: "Switch to {{mm}}mm",
  cancel_and_edit: "Cancel, let me adjust",
  create_anyway: "Create anyway",
  warning:
    "This tool ({{tool}} mm) covers only {{percent}}% ({{area}} mm² will not be carved). Switch to a {{suggested}} mm tool for near-full coverage, or continue with the current tool.",
  no_suggestion:
    "This tool ({{tool}} mm) covers only {{percent}}%. No smaller standard tool fully covers this detail.",
},
      new_project: {
        page_title_1: "Start",
        page_title_2: "New Project",
        analysis_preview: "ANALYSIS PREVIEW",
        processing_ai: "PROCESSING AI...",
        select_image: "Select an image to start analysis",
        ai_stages: "AI Processing Stages",
chosen_tool: "Chosen Tool",
  suggested_tool: "Suggested Tool",
  unreachable_area: "Unreachable Area",
        tech_stats: "TECHNICAL STATISTICS",
        cutting_area: "Cutting Area",
        coverage_percent: "Coverage",
        est_points: "Est. Points",
        threshold: "Threshold",
        tool_used: "Tool Used",
        tool_auto_switched:
          "Coverage wasn't full with your chosen bit, so the engine auto-switched to a {{suggested}}mm tool for this preview.",
      },
      project_details: {
        edit_info: "Edit Project Info",
        update_success: "Updated Successfully!",
        project_title: "Project Title",
        width_x: "Width (mm)",
        height_y: "Height (mm)",
        min_dimension_error: "Must be at least {{min}} mm",
        safe_z: "Safe Height Z",
        saving: "SAVING...",
        save_changes: "SAVE CHANGES",
        back_to_projects: "Back to Projects",
        delete_project: "Delete Project",
        confirm_delete: "Are you sure you want to delete this project?",
        error_not_found: "Project not found",
        cut_depth: "Depth (Z)",
cut_depth_hint: "Negative value = depth into the material (e.g. -3).",
feed_rate: "Feed Rate",
plunge_rate: "Plunge Rate",
spindle_speed: "Spindle Speed",
machine_hourly_rate: "Machine Rate",
      },
      project_terminal: {
        title: "G-Code Generator",
        subtitle: "Process project to generate toolpaths.",
        btn_generate: "GENERATE",
        btn_processing: "PROCESSING...",
        btn_download: "DOWNLOAD",
        awaiting_command:
          "// Awaiting command...\n// Click 'GENERATE' to process image and view G-Code toolpaths.",
        status_processing:
          "// Running on the server, this can take a minute for detailed designs...",
        preview_3d_title: "3D Toolpath Preview",
        tab_terminal: "Terminal",
        tab_3d: "3D Preview",
        tab_report: "Report",
        expand: "Expand to fullscreen",
        open_new_tab: "Open in new tab",
        close: "Close",
        progress_label: "Generating G-Code...",
progress_hint: "This can take a minute for detailed designs. You can stay on this page.",
      },
 machining_report: {
  title: "Machining Summary",
  subtitle: "Key estimates for this toolpath before you download.",
  time_label: "Estimated Time",
  time_sub: "Cutting {{cut}} • Rapid {{rapid}}",
  material_label: "Material Removed",
  material_sub_stepover: "Based on stepover width",
  material_sub_tool: "Based on tool diameter (single contour)",
  material_unavailable: "Tool diameter not set",
  cost_label: "Estimated Cost",
  cost_sub: "@ {{rate}}/hr machine rate",
  cost_unavailable: "No hourly rate set",
  cutting_length: "Cutting Path Length",
  rapid_travel: "Rapid Travel",
  rapid_xy: "Rapid XY",
  rapid_z: "Rapid Z (lifts)",
  paths_processed: "Paths Processed",
  points: "Valid Points",
  segments: "G1 / G2-G3",
  peak_mrr: "Material Removal Rate",
  mrr_status_safe: "Within safe range",
  mrr_status_high: "High load — review settings",
  stock_size: "Work Area",
  file_size: "G-Code File Size",
  gcode_lines: "G-Code Lines",
  generation_time: "Generation Time",
  tech_details: "Technical details",
  warnings: "Warnings",
  no_report: "Generate the G-Code to see the machining summary.",
  warn_duplicate_summary:
  "{{count}} path(s) have near-duplicate points that may affect arc matching.",
warn_more: "And {{count}} more warning(s).",
warn_generic: "{{count}} warning(s) were reported during generation.",
},
      settings: {
        security_title: "Security",
        old_password: "Old Password",
        new_password: "New Password",
        confirm_new_password: "Confirm New Password",
        processing: "PROCESSING...",
        save_changes: "SAVE CHANGES",
        user_id: "User ID",
        username: "Username",
        email: "Email",
        no_email: "No email provided",
        page_title_1: "Account",
        page_title_2: "Settings",
        page_subtitle: "Manage your profile and security preferences.",
      },
      all_patterns: {
        badge: "DISCOVER DESIGNS",
        title_1: "Patterns",
        title_2: "Library",
        subtitle:
          "Explore high-quality, community-shared CNC patterns ready for your next project.",
        fetching: "Fetching latest patterns...",
        artist: "Artist",
        view_details: "VIEW DETAILS",
        load_more: "LOAD MORE COLLECTIONS",
        try_again: "Try Again",
      },
      simulator: {
        title_1: "G-Code",
        title_2: "Simulator",
        subtitle:
          "Upload existing G-code files and preview their 3D toolpaths.",
        btn_upload: "Upload G-Code",
        hide_form: "Hide form",
        upload_title: "Upload G-Code file",
        drag_drop: "Drag & drop your .nc / .gcode file here",
        accepted_types: "Accepted: .nc, .gcode, .txt",
        field_title: "Title",
        field_title_placeholder: "e.g. Spade pin toolpath",
        width_x: "Wood width mm",
        height_y: "Wood height mm",
        min_dimension_error: "Must be at least {{min}} mm",
        uploading: "Uploading & generating simulation...",
        upload_btn: "Upload & Simulate",
        no_uploads_title: "No uploads yet",
        no_uploads_desc: "Upload a G-code file to generate a 3D simulation.",
        load_more: "Load more",
        view_details: "Details",
        download: "Download",
        delete: "Delete",
        confirm_delete: "Delete this upload permanently?",
        has_simulation: "3D simulation ready",
        status_completed: "COMPLETED",
        status_failed: "FAILED",
        status_processing: "PROCESSING",
        status_unknown: "UNKNOWN",
        line_count: "{{count}} lines",
        back: "Back to Simulator",
        error_not_found: "Upload not found",
        preview_3d: "3D Toolpath Preview",
        open_new_tab: "Open in new tab",
        no_simulation: "No simulation available for this upload.",
      },
      tour: {
  next: "Next",
  prev: "Back",
  done: "Finish",
  close: "Skip",
  restart: "Show guide",
  brand_title: "Welcome to Zukhruf",
  brand_desc:
    "Your smart CNC platform — convert designs into precise machine-ready toolpaths in a few clicks.",
  nav_title: "Main navigation",
  nav_desc:
    "Move between Home, Gallery, your Projects, and the G-Code Simulator from here.",
  lang_title: "Language",
  lang_desc: "Switch between Arabic and English anytime.",
  theme_title: "Theme",
  theme_desc: "Toggle dark or light mode to match your preference.",
  auth_title: "Sign in or create an account",
  auth_desc:
    "Log in or register to create projects, generate G-code, and save your work.",
  settings_title: "Settings & profile",
  settings_desc: "Manage your account, password, and preferences.",
  new_project_nav_title: "Projects",
  new_project_nav_desc:
    "Open Projects then start a new project to turn an image into CNC toolpaths.",
  np_upload_title: "Upload your design",
  np_upload_desc:
    "Drag & drop an image (JPG, PNG, SVG) or browse to start. This is Step 1 of creating a project.",
  np_settings_title: "CNC setup",
  np_settings_desc:
    "Set wood dimensions, tool diameter, feed rates, and other machining parameters.",
  np_preview_title: "Live AI preview",
  np_preview_desc:
    "See analysis stages, coverage, and toolpath preview before you commit.",
  np_create_title: "Create the project",
  np_create_desc:
    "When settings look good, create the project. The system will process and prepare G-code.",
  np_download_title: "Download G-Code",
  np_download_desc:
    "After processing, download the .nc / G-code file ready for your CNC machine.",
  pd_report_title: "Machining report",
  pd_report_desc:
    "View estimated time, cost, coverage, and technical stats for the toolpath.",
  sim_nav_title: "G-Code Simulator",
  sim_nav_desc:
    "Upload existing G-code files and inspect their 3D toolpaths without creating a full project.",
sim_viewer_title: "3D simulation viewer",
  sim_viewer_desc:
    "Inspect the toolpath in 3D, open it in a new tab, and verify the motion before machining.",
  done_title: "You're ready!",
  done_desc:
    "You can restart this guide anytime from the help icon in the navbar. Happy machining!",
    "pd_edit_title": "Edit project settings",
"pd_edit_desc": "Change the project title, wood dimensions, and cut depth, then save.",
"pd_generate_title": "Generate / re-generate G-Code",
"pd_generate_desc": "Run processing to produce toolpaths from the project image.",
"pd_download_title": "Download G-Code",
"pd_download_desc": "After generation finishes, download the file for your CNC machine.",
"pd_tab_terminal_title": "Terminal tab",
"pd_tab_terminal_desc": "Shows processing log and the generated G-Code text.",
"pd_tab_3d_title": "3D Preview tab",
"pd_tab_3d_desc": "Interactive preview of the toolpaths before machining.",
"pd_tab_report_title": "Report tab",
"pd_tab_report_desc": "Summary: cut length, estimated time, cost, and path counts.",
"home_start_title": "Start Processing",
"home_start_desc": "Create a new project, upload your ornament image, and generate G-Code.",
"home_explore_title": "Explore Gallery",
"home_explore_desc": "Browse public designs and patterns available on the platform.",
"home_view_all_title": "View All Patterns",
"home_view_all_desc": "Opens the full list of public patterns.",
"home_pattern_card_title": "Pattern card",
"home_pattern_card_desc": "Click any card to open pattern details and use it in a new project.",
"home_cta_title": "Create your project",
"home_cta_desc": "Start a new project directly from the home page.",
gallery_upload_title: "Upload new image",
gallery_upload_desc: "Add a new ornament image to your gallery and start a CNC project from it.",
gallery_filter_all_title: "All images",
gallery_filter_all_desc: "Show every image you uploaded, including patterns and regular designs.",
gallery_filter_patterns_title: "My patterns",
gallery_filter_patterns_desc: "Show only images marked as reusable patterns.",
gallery_card_title: "Image card",
gallery_card_desc: "Hover a card to see actions: view details, start CNC project, or delete.",
gallery_card_view_title: "View details",
gallery_card_view_desc: "Open the full image page with description and project actions.",
gallery_card_start_title: "Quick start",
gallery_card_start_desc: "Create a CNC project from this image and open its setup page.",
gallery_card_delete_title: "Delete image",
gallery_card_delete_desc: "Remove this image from your gallery permanently.",
gd_back_title: "Back to gallery",
gd_back_desc: "Return to your image list.",
gd_preview_title: "Image preview",
gd_preview_desc: "This is the selected design that will be converted into toolpaths.",
gd_start_title: "Start CNC project",
gd_start_desc: "Continue to project setup: wood size, tool diameter, then generate G-code.",
gd_delete_title: "Delete image",
gd_delete_desc: "Delete this image if you no longer need it.",
projects_new_title: "New project",
projects_new_desc: "Start a new CNC project from an uploaded image or pattern.",
projects_view_title: "View project",
projects_view_desc: "Open project details: status, simulation, report, and G-code.",
projects_download_title: "Download G-code",
projects_download_desc: "Download the .nc file when the project status is Completed.",
projects_delete_title: "Delete project",
projects_delete_desc: "Permanently remove this project after confirmation.",
sim_upload_title: "Upload G-Code",
sim_upload_desc: "Open the form to upload a .nc / .gcode file, set wood size, and start 3D simulation.",
sim_card_details_title: "Open details",
sim_card_details_desc: "View file info and the interactive 3D toolpath preview.",
sim_card_download_title: "Download file",
sim_card_download_desc: "Download the uploaded G-code file to your device.",
sim_card_delete_title: "Delete upload",
sim_card_delete_desc: "Remove this upload and its simulation after confirmation.",
sim_back_title: "Back to list",
sim_back_desc: "Return to all uploaded G-code files.",
sim_preview_title: "3D toolpath preview",
sim_preview_desc: "Rotate and inspect the simulated toolpath before using the file on the machine.",
sim_download_title: "Download G-Code",
sim_download_desc: "Download the G-code file from this detail page.",
sim_delete_title: "Delete",
sim_delete_desc: "Permanently delete this upload and its simulation.",
settings_profile_title: "Your profile",
settings_profile_desc: "View your username, user ID, and linked email.",
settings_security_title: "Security",
settings_security_desc: "Change your password by entering the old password and the new one twice.",
settings_save_title: "Save changes",
settings_save_desc: "Apply the new password after filling all security fields.",
},
    },
  },
  ar: {
    translation: {
      nav: {
        home: "الرئيسية",
        brand_name: "زخرف",
        gallery: "المعرض",
        projects: "المشاريع",
        simulator: "المحاكي",
        login: "تسجيل الدخول",
        register: "إنشاء حساب",
      },
      home: {
        hero_badge: "مولّد مسارات التشغيل الذكي للتحكم الرقمي",
        hero_title_1: "فن الدقة في",
        hero_title_2: "التصنيع الذكي",
        hero_desc:
          "حوّل خيالك الهندسي إلى واقع ميكانيكي ملموس. يوفّر زخرف أدق وأسرع أدوات المعالجة لتوليد مسارات G-Code بنقرة واحدة.",
        btn_start: "ابدأ المعالجة",
        btn_explore: "استكشف المعرض",

        feature_offset_title: "إزاحة متكيفة",
        feature_offset_desc:
          "تتبع المسارات العرض الحقيقي للزخرفة؛ إذ تحصل المناطق العريضة على ممرات أكثر، بينما تبقى المناطق الرفيعة آمنة.",
        feature_arcs_title: "مسارات قوسية نظيفة",
        feature_arcs_desc:
          "تُحوَّل المنحنيات إلى أقواس G2/G3 بدلاً من آلاف خطوط G1 المتعرجة.",
        feature_coverage_title: "معاينة التغطية",
        feature_coverage_desc:
          "افحص مدى وصول الأداة قبل الحفر، وبدّل القطر عندما تحتاج التفاصيل الدقيقة إلى أداة أصغر.",

        steps_title_1: "كيف",
        steps_title_2: "يعمل؟",
        steps_subtitle: "ثلاث خطوات بسيطة بين صورتك ومسار جاهز للآلة.",
        steps_title: "كيف يعمل النظام",
        step1_title: "رفع الصورة",
        step1_desc: "قم برفع تصميمك أو زخرفتك بصيغة JPG أو PNG.",
        step2_title: "معالجة الذكاء الاصطناعي",
        step2_desc:
          "تقوم خوارزمياتنا بتحليل الصورة وتحويلها إلى متجهات.",
        step3_title: "توليد G-Code",
        step3_desc: "حمّل مسار الآلة الجاهز للعمل مباشرة.",

        patterns_title_1: "زخارف",
        patterns_title_2: "عامة",
        patterns_desc: "تصاميم احترافية ومتناسقة من المجتمع.",
        btn_view_all: "عرض جميع الزخارف",
        pattern_badge: "نمط عام",
        no_description: "لا يوجد وصف",
        user: "مستخدم",

        cta_title: "هل أنت مستعد لتحويل تصاميمك؟",
        cta_desc:
          "انضم إلى آلاف الصنّاع والمهندسين وابدأ بتوليد مسارات التحكم الرقمي في ثوانٍ معدودة.",
        btn_create_account: "أنشئ مشروعك الآن",
      },
      auth: {
        login_title: "مرحباً بعودتك",
        login_subtitle: "يرجى إدخال بياناتك لتسجيل الدخول.",
        username: "اسم المستخدم",
        username_placeholder: "أدخل اسم المستخدم",
        password: "كلمة المرور",
        password_placeholder: "أدخل كلمة المرور",
        logging_in: "جاري تسجيل الدخول...",
        login_btn: "تسجيل الدخول",
        no_account: "ليس لديك حساب؟",
        create_account_link: "إنشاء حساب جديد",

        register_title: "إنشاء حساب",
        register_subtitle: "سجّل الآن لتبدأ في إنشاء مشاريع التحكم الرقمي الخاصة بك.",
        choose_username: "اختر اسم مستخدم",
        email: "البريد الإلكتروني",
        optional: "(اختياري)",
        email_placeholder: "أدخل بريدك الإلكتروني",
        create_password: "أنشئ كلمة مرور",
        confirm_password: "تأكيد كلمة المرور",
        reenter_password: "أعد إدخال كلمة المرور",
        creating_account: "جاري إنشاء الحساب...",
        register_btn: "التسجيل الآن",
        has_account: "لديك حساب بالفعل؟",
        login_link: "سجّل الدخول من هنا",

        hero_desc:
          "المنصة الأسرع والأكثر دقة لتحويل التصاميم إلى مسارات تحكم رقمي جاهزة للآلة.",
        copyright: "© 2026 منصة زخرف. جميع الحقوق محفوظة.",
        login_hero_title: "حوّل خيالك",
        login_hero_subtitle: "إلى واقع ملموس",
        login_feat_1: "معالجة فائقة السرعة لملفات G-Code",
        login_feat_2: "إدارة متكاملة للمشاريع",
        login_feat_3: "دقة عالية لجميع آلات التحكم الرقمي",

        register_hero_title: "ابدأ رحلتك",
        register_hero_subtitle: "في التصنيع الذكي",
        register_feat_1: "توليد فوري لمسارات G-Code",
        register_feat_2: "مكتبة زخارف عامة",
        register_feat_3: "واجهة تحكم متقدمة وسهلة الاستخدام",
      },
      footer: {
        desc: "المنصة الهندسية المتكاملة لمعالجة الصور وتوليد G-Code. صُممت من أجل الدقة والمبدعين.",
        quick_links: "روابط سريعة",
        link_home: "الصفحة الرئيسية",
        link_gallery: "استكشف المعرض",
        link_new_project: "إنشاء مشروع جديد",
        link_projects: "مشاريعي",
        connect: "تواصل معنا",
        connect_desc: "هل لديك أسئلة أو ملاحظات؟ لا تتردد في التواصل معنا.",
        copyright: "© 2026 منصة زخرف. جميع الحقوق محفوظة.",
      },
      coverage_modal: {
  title: "فحص قطر الأداة",
  current_tool: "أداتك الحالية",
  suggested_tool: "المقترحة",
  coverage_percent: "نسبة التغطية",
  keep_current: "الإبقاء على {{mm}} مم",
  switch_to: "التبديل إلى {{mm}} مم",
  cancel_and_edit: "إلغاء، أرغب في التعديل",
  create_anyway: "الإنشاء على أي حال",
  warning:
    "هذه الأداة ({{tool}} مم) تغطي {{percent}}% فقط (لن يُحفر {{area}} مم²). يُفضَّل التبديل إلى أداة قطرها {{suggested}} مم للحصول على تغطية شبه كاملة، أو المتابعة بالأداة الحالية.",
  no_suggestion:
    "هذه الأداة ({{tool}} مم) تغطي {{percent}}% فقط. لا توجد أداة قياسية أصغر تغطي هذا التفصيل بالكامل.",
},
      gallery: {
        title_1: "معرض",
        title_2: "الصور",
        subtitle: "إدارة صورك وزخارفك المرفوعة.",
        btn_upload: "رفع جديد",
        filter_all: "جميع الصور",
        filter_patterns: "زخارفي",
        no_images_title: "لا توجد صور",
        no_images_desc: "لم تقم برفع أي {{type}} بعد.",
        type_patterns: "زخارف",
        type_images: "صور",
        loading: "جاري التحميل...",
        btn_load_more: "تحميل المزيد من الصور",
        no_description: "لا يوجد وصف",
        uploaded_by: "بواسطة",
        btn_delete: "حذف",
        confirm_delete: "هل أنت متأكد من رغبتك في حذف هذه الصورة؟",
        btn_delete_all: "حذف الكل",
        deleting_all: "جاري الحذف...",
        confirm_delete_all:
          "هل أنت متأكد من رغبتك في حذف جميع صورك وزخارفك نهائياً؟ لا يمكن التراجع عن هذه الخطوة.",
        badge_pattern: "نمط عام",
        view_details: "عرض التفاصيل",
        generate_gcode: "توليد G-Code",
        delete_image: "حذف الصورة",
        id_prefix: "المعرّف:",
      },
      projects: {
        title_1: "مشاريعي",
        title_2: "السابقة",
        subtitle: "عرض وإدارة مسارات التحكم الرقمي التي قمت بتوليدها.",
        btn_new: "مشروع جديد",
        no_projects_title: "لا توجد مشاريع بعد",
        no_projects_desc: "لم تقم بإنشاء أي مشاريع تحكم رقمي حتى الآن.",
        loading: "جاري التحميل...",
        btn_load_more: "تحميل المزيد من المشاريع",
        badge_completed: "مكتمل",
        no_description: "لا يوجد وصف",
        dimensions: "الأبعاد",
        depth: "العمق",
        est_time: "الوقت المقدَّر",
        minutes: "دقيقة",
        btn_delete: "حذف المشروع",
        confirm_delete: "هل أنت متأكد من رغبتك في حذف هذا المشروع؟",
        status_completed: "مكتمل",
        status_unknown: "غير معروف",
        status_failed: "فشل",
        status_processing_badge: "قيد المعالجة",
        dim: "الأبعاد:",
        view_details: "عرض التفاصيل",
        get_nc: "تحميل ملف المسار",
        pending: "قيد الانتظار",
        delete_project: "حذف المشروع",
      },
      new_project_sidebar: {
        drag_drop: "اسحب الصورة وأفلتها هنا",
        or: "أو",
        browse: "تصفح الملفات",
          file_too_large: "حجم الصورة أكبر من 15 ميغابايت. الرجاء اختيار صورة أصغر من 15 MB.",
        step1_title: "الخطوة 1: تفاصيل الصورة",
        image_title: "عنوان الصورة",
        description: "الوصف",
        save_pattern: "حفظ كزخرفة عامة",
        uploading: "جاري الرفع...",
        upload_btn: "رفع الصورة إلى الخادم",
        step2_title: "الخطوة 2: إعدادات الآلة",
        width_x: "العرض (مم)",
        height_y: "الارتفاع (مم)",
        min_dimension_error: "يجب أن تكون القيمة {{min}} مم على الأقل",
        tool_diameter: "قطر الأداة (مم)",
        tool_diameter_hint:
          "القطر الأصغر يعطي تفاصيل أدق لكنه أبطأ. قد يبدّل المحرك تلقائياً إلى قطر أكبر إذا تعذّر على القطر الحالي الوصول إلى جميع تفاصيل التصميم.",
        analyzing: "جاري تحليل الصورة...",
        preview_ai: "معاينة معالجة الذكاء الاصطناعي",
        checking_coverage: "جاري فحص التغطية...",
        creating: "جاري الإنشاء...",
        project_created: "تم إنشاء المشروع",
        create_project: "إنشاء المشروع",
        cut_depth: "عمق القطع (Z)",
        cut_depth_hint: "القيمة السالبة تمثل العمق داخل المادة (مثال: -3 مم).",
        safe_z: "ارتفاع الأمان (Z)",
        feed_rate: "سرعة التغذية",
        plunge_rate: "سرعة الغوص",
        spindle_speed: "سرعة المغزل",
        machine_hourly_rate: "تكلفة ساعة تشغيل الآلة",
      },
confirm_delete_modal: {
  title: "تأكيد الحذف",
  message: "هل أنت متأكد من رغبتك في حذف هذا العنصر؟ لا يمكن التراجع عن هذا الإجراء.",
  message_with_name: "هل أنت متأكد من رغبتك في حذف \"{{name}}\"؟ لا يمكن التراجع عن هذا الإجراء.",
  warning: "هذا الإجراء نهائي ولا يمكن التراجع عنه.",
  confirm: "نعم، احذف",
  cancel: "إلغاء",
  close: "إغلاق",
},
      image_details: {
        badge_pattern: "نمط عام",
        uploaded_on: "تاريخ الرفع:",
        description: "الوصف",
        no_description:
          "لم يُقدَّم وصف لهذه الصورة. يمكنك المتابعة لإنشاء مسارات التحكم الرقمي مباشرة.",
        actions: "الإجراءات",
        btn_start_project: "بدء مشروع تحكم رقمي",
        btn_starting_project: "جاري إنشاء المشروع...",
        error_start_project: "فشل إنشاء مشروع التحكم الرقمي. يُرجى المحاولة مرة أخرى.",
        btn_delete_image: "حذف الصورة",
        default_alt: "صورة",
        confirm_delete: "هل أنت متأكد من رغبتك في حذف هذه الصورة؟",
      },
      new_project: {
        page_title_1: "بدء",
        page_title_2: "مشروع جديد",
        analysis_preview: "معاينة التحليل",
        processing_ai: "جاري معالجة الذكاء الاصطناعي...",
        select_image: "حدّد صورة لبدء التحليل",
        ai_stages: "مراحل معالجة الذكاء الاصطناعي",
chosen_tool: "الأداة المختارة",
  suggested_tool: "الأداة المقترحة",
  unreachable_area: "المساحة غير القابلة للوصول",
        tech_stats: "إحصائيات فنية",
        cutting_area: "مساحة القطع",
        coverage_percent: "نسبة التغطية",
        est_points: "النقاط المقدَّرة",
        threshold: "العتبة",
        tool_used: "القطر المستخدم",
        tool_auto_switched:
          "لم تكن التغطية كاملة بالقطر الذي اخترته، لذا بدّل المحرك تلقائياً إلى قطر {{suggested}} مم في هذه المعاينة.",
      },
      project_details: {
        edit_info: "تعديل معلومات المشروع",
        update_success: "تم التحديث بنجاح",
        project_title: "عنوان المشروع",
        width_x: "العرض (مم)",
        height_y: "الارتفاع (مم)",
        min_dimension_error: "يجب أن تكون القيمة {{min}} مم على الأقل",
        safe_z: "ارتفاع الأمان (Z)",
        saving: "جاري الحفظ...",
        save_changes: "حفظ التغييرات",
        back_to_projects: "العودة إلى المشاريع",
        delete_project: "حذف المشروع",
        confirm_delete: "هل أنت متأكد من رغبتك في حذف هذا المشروع؟",
        error_not_found: "المشروع غير موجود",
        cut_depth: "عمق القطع (Z)",
        cut_depth_hint: "القيمة السالبة تمثل العمق داخل المادة (مثال: -3 مم).",
        feed_rate: "سرعة التغذية",
        plunge_rate: "سرعة الغوص",
        spindle_speed: "سرعة المغزل",
        machine_hourly_rate: "تكلفة ساعة التشغيل",
      },
      project_terminal: {
        title: "مولّد G-Code",
        subtitle: "قم بمعالجة المشروع لتوليد مسارات القطع.",
        btn_generate: "توليد",
        btn_processing: "جاري المعالجة...",
        btn_download: "تحميل",
        awaiting_command:
          "// في انتظار الأمر...\n// اضغط على «توليد» لمعالجة الصورة وعرض مسارات G-Code.",
        status_processing:
          "// جاري التنفيذ على الخادم، وقد يستغرق ذلك دقيقة للتصاميم التفصيلية...",
        preview_3d_title: "معاينة المسار ثلاثية الأبعاد",
        tab_terminal: "الطرفية",
        tab_3d: "معاينة ثلاثية الأبعاد",
        tab_report: "التقرير",
        expand: "توسيع إلى وضع ملء الشاشة",
        open_new_tab: "فتح في تبويب جديد",
        close: "إغلاق",
        progress_label: "جاري توليد G-Code...",
        progress_hint:
          "قد يستغرق ذلك دقيقة للتصاميم التفصيلية. يمكنك البقاء في هذه الصفحة.",
      },
machining_report: {
  title: "ملخص عملية التشغيل",
  subtitle: "أبرز التقديرات لهذا المسار قبل التحميل.",
  time_label: "زمن التشغيل المتوقع",
  time_sub: "قطع {{cut}} • حركة سريعة {{rapid}}",
  material_label: "حجم المادة المزالة",
  material_sub_stepover: "بالاعتماد على مسافة التداخل بين الممرات",
  material_sub_tool: "بالاعتماد على قطر الأداة (خط قطع واحد)",
  material_unavailable: "لم يتم تحديد قطر الأداة",
  cost_label: "التكلفة التقديرية",
  cost_sub: "بمعدل {{rate}} لكل ساعة تشغيل",
  cost_unavailable: "لم يتم تحديد سعر ساعة التشغيل",
  cutting_length: "طول مسار القطع",
  rapid_travel: "طول الحركة السريعة",
  rapid_xy: "حركة سريعة XY",
  rapid_z: "رفع آمن Z",
  paths_processed: "المسارات المعالجة",
  points: "النقاط الصالحة",
  segments: "G1 / G2-G3",
  peak_mrr: "معدل إزالة المادة",
  mrr_status_safe: "ضمن النطاق الآمن",
  mrr_status_high: "حمل قطع مرتفع — يُنصح بمراجعة الإعدادات",
  stock_size: "مساحة التشغيل",
  file_size: "حجم ملف G-code",
  gcode_lines: "عدد أسطر الملف",
  generation_time: "زمن توليد الملف",
  tech_details: "التفاصيل الفنية",
  warnings: "التحذيرات",
  no_report: "قم بتوليد G-code لعرض ملخص التشغيل.",
  warn_duplicate_summary:
  "{{count}} مسارًا يحتوي نقاطًا متقاربة قد تؤثر على مطابقة الأقواس.",
warn_more: "و{{count}} تحذيرًا إضافيًا.",
warn_generic: "ظهر {{count}} تحذيرًا أثناء التوليد.",
},
      settings: {
        security_title: "الأمان",
        old_password: "كلمة المرور الحالية",
        new_password: "كلمة المرور الجديدة",
        confirm_new_password: "تأكيد كلمة المرور الجديدة",
        processing: "جاري المعالجة...",
        save_changes: "حفظ التغييرات",
        user_id: "معرّف المستخدم",
        username: "اسم المستخدم",
        email: "البريد الإلكتروني",
        no_email: "لم يُوفَّر بريد إلكتروني",
        page_title_1: "إعدادات",
        page_title_2: "الحساب",
        page_subtitle: "إدارة ملفك الشخصي وتفضيلات الأمان.",
      },
      all_patterns: {
        badge: "اكتشف التصاميم",
        title_1: "مكتبة",
        title_2: "الزخارف",
        subtitle:
          "استكشف زخارف تحكم رقمي عالية الجودة ومشارَكة من المجتمع، لتكون جاهزة لمشروعك القادم.",
        fetching: "جاري جلب أحدث الزخارف...",
        artist: "فنان",
        view_details: "عرض التفاصيل",
        load_more: "تحميل المزيد من المجموعات",
        try_again: "إعادة المحاولة",
      },
      simulator: {
        title_1: "محاكي",
        title_2: "G-Code",
        subtitle: "ارفع ملفات G-Code جاهزة وشاهد مسارها ثلاثي الأبعاد.",
        btn_upload: "رفع G-Code",
        hide_form: "إخفاء النموذج",
        upload_title: "رفع ملف G-Code",
        drag_drop: "اسحب ملف .nc أو .gcode وأفلته هنا",
        accepted_types: "الصيغ المدعومة: .nc، .gcode، .txt",
        field_title: "العنوان",
        field_title_placeholder: "مثال: مسار دبوس الزخرفة",
        width_x: "عرض الخشب (مم)",
        height_y: "ارتفاع الخشب (مم)",
        min_dimension_error: "يجب أن تكون القيمة {{min}} مم على الأقل",
        uploading: "جاري الرفع وتوليد المحاكاة...",
        upload_btn: "رفع ومحاكاة",
        no_uploads_title: "لا توجد ملفات مرفوعة بعد",
        no_uploads_desc: "ارفع ملف G-Code لتوليد محاكاة ثلاثية الأبعاد.",
        load_more: "تحميل المزيد",
        view_details: "التفاصيل",
        download: "تحميل",
        delete: "حذف",
        confirm_delete: "هل أنت متأكد من حذف هذا الملف نهائياً؟",
        has_simulation: "المحاكاة جاهزة",
        status_completed: "مكتمل",
        status_failed: "فشل",
        status_processing: "قيد المعالجة",
        status_unknown: "غير معروف",
        line_count: "{{count}} سطر",
        back: "العودة إلى المحاكي",
        error_not_found: "الملف غير موجود",
        preview_3d: "معاينة المسار ثلاثية الأبعاد",
        open_new_tab: "فتح في تبويب جديد",
        no_simulation: "لا توجد محاكاة لهذا الملف.",
      },
tour: {
  next: "التالي",
  prev: "السابق",
  done: "إنهاء",
  close: "تخطي",
  restart: "عرض الدليل",

  brand_title: "مرحباً بك في زخرف",
  brand_desc:
    "منصتك الذكية للتحكم الرقمي؛ حوّل تصاميمك إلى مسارات تشغيل جاهزة للآلة بدقة وسرعة.",

  nav_title: "القائمة الرئيسة",
  nav_desc:
    "انتقل من هنا بين الصفحة الرئيسة، والمعرض، ومشاريعك، ومحاكي ملفات G-Code.",

  lang_title: "اللغة",
  lang_desc: "بدّل بين العربية والإنجليزية في أي وقت.",

  theme_title: "الوضع الداكن / الفاتح",
  theme_desc: "غيّر مظهر الواجهة بين الوضع الداكن والوضع الفاتح وفق تفضيلك.",

  auth_title: "تسجيل الدخول أو إنشاء حساب",
  auth_desc:
    "سجّل دخولك أو أنشئ حساباً لإنشاء المشاريع، وتوليد ملفات G-Code، وحفظ أعمالك.",

  settings_title: "الإعدادات والملف الشخصي",
  settings_desc: "أدر حسابك، وكلمة المرور، وتفضيلات الاستخدام.",

  new_project_nav_title: "المشاريع",
  new_project_nav_desc:
    "انتقل إلى المشاريع، ثم ابدأ مشروعاً جديداً لتحويل الصورة إلى مسارات تشغيل رقمية.",

  np_upload_title: "رفع التصميم",
  np_upload_desc:
    "اسحب صورة بصيغة JPG أو PNG أو SVG، أو اختر ملفاً من جهازك. هذه هي الخطوة الأولى لإنشاء المشروع.",

  np_settings_title: "إعدادات التشغيل الرقمي",
  np_settings_desc:
    "حدّد أبعاد قطعة الخشب، وقطر أداة القطع، وسرعات التغذية، وسائر معاملات التشغيل.",

  np_preview_title: "معاينة المعالجة الذكية",
  np_preview_desc:
    "اطّلع على مراحل التحليل، ونسبة التغطية، ومعاينة المسار قبل تأكيد إنشاء المشروع.",

  np_create_title: "إنشاء المشروع",
  np_create_desc:
    "بعد اكتمال الإعدادات، أنشئ المشروع ليقوم النظام بالمعالجة وتجهيز ملف G-Code.",

  np_download_title: "تحميل ملف G-Code",
  np_download_desc:
    "بعد انتهاء المعالجة، حمّل ملف ‎.nc / G-Code الجاهز للاستخدام على آلة التحكم الرقمي.",

  pd_report_title: "تقرير التشغيل",
  pd_report_desc:
    "اطّلع على الزمن التقديري، والتكلفة، ونسبة التغطية، والإحصاءات الفنية للمسار.",

  sim_nav_title: "محاكي G-Code",
  sim_nav_desc:
    "ارفع ملفات G-Code جاهزة، واستعرض مسارها ثلاثي الأبعاد دون إنشاء مشروع كامل.",

  sim_viewer_title: "عارض المحاكاة ثلاثية الأبعاد",
  sim_viewer_desc:
    "افحص المسار بصورة ثلاثية الأبعاد، وافتحه في تبويب جديد، وتأكد من صحة الحركة قبل التشغيل.",

  done_title: "أصبحت جاهزاً",
  done_desc:
    "يمكنك إعادة تشغيل الدليل في أي وقت من أيقونة المساعدة في الشريط العلوي. نتمنى لك عملاً موفقاً.",

  pd_edit_title: "تعديل إعدادات المشروع",
  pd_edit_desc:
    "من هنا يمكنك تعديل عنوان المشروع، وأبعاد قطعة الخشب، وعمق الحفر، ثم حفظ التغييرات.",

  pd_generate_title: "توليد G-Code أو إعادة توليده",
  pd_generate_desc:
    "اضغط زر التوليد لتشغيل المعالجة وإنشاء ملف مسارات التشغيل من جديد.",

  pd_download_title: "تحميل ملف G-Code",
  pd_download_desc:
    "بعد اكتمال التوليد، حمّل الملف النهائي لاستخدامه على آلة التحكم الرقمي.",

  pd_tab_terminal_title: "تبويب السجل",
  pd_tab_terminal_desc:
    "يعرض سجل المعالجة ونص ملف G-Code الناتج.",

  pd_tab_3d_title: "المعاينة ثلاثية الأبعاد",
  pd_tab_3d_desc:
    "معاينة مسارات الحفر بصورة تفاعلية قبل التشغيل على الآلة.",

  pd_tab_report_title: "تقرير التشغيل",
  pd_tab_report_desc:
    "ملخص الإحصاءات: طول القطع، والزمن التقديري، والتكلفة، وعدد المسارات.",

  home_start_title: "ابدأ المعالجة",
  home_start_desc:
    "اضغط هنا لإنشاء مشروع جديد، ورفع صورة الزخرفة، وتحويلها إلى ملف G-Code.",

  home_explore_title: "استكشف المعرض",
  home_explore_desc:
    "تصفّح التصاميم والأنماط العامة المتاحة في المنصة.",

  home_view_all_title: "عرض جميع الأنماط",
  home_view_all_desc:
    "يفتح قائمة كاملة بجميع الأنماط العامة.",

  home_pattern_card_title: "بطاقة النمط",
  home_pattern_card_desc:
    "اضغط أي بطاقة لفتح تفاصيل النمط واستخدامه في مشروع جديد.",

  home_cta_title: "أنشئ مشروعك الآن",
  home_cta_desc:
    "من هنا يمكنك بدء مشروع جديد مباشرة من الصفحة الرئيسة.",

  gallery_upload_title: "رفع صورة جديدة",
  gallery_upload_desc:
    "أضف زخرفة جديدة إلى معرضك، وابدأ منها مشروع تشغيل رقمي.",

  gallery_filter_all_title: "جميع الصور",
  gallery_filter_all_desc:
    "عرض كل الصور المرفوعة، بما في ذلك الزخارف والصور العادية.",

  gallery_filter_patterns_title: "زخارفي",
  gallery_filter_patterns_desc:
    "عرض الصور المحفوظة بوصفها زخارف قابلة لإعادة الاستخدام فقط.",

  gallery_card_title: "بطاقة الصورة",
  gallery_card_desc:
    "مرّر فوق البطاقة لعرض الإجراءات: عرض التفاصيل، أو بدء مشروع، أو الحذف.",

  gallery_card_view_title: "عرض التفاصيل",
  gallery_card_view_desc:
    "فتح صفحة الصورة الكاملة مع الوصف وإجراءات المشروع.",

  gallery_card_start_title: "بدء سريع",
  gallery_card_start_desc:
    "إنشاء مشروع تشغيل رقمي من هذه الصورة والانتقال إلى إعداداته.",

  gallery_card_delete_title: "حذف الصورة",
  gallery_card_delete_desc:
    "إزالة هذه الصورة من المعرض نهائياً.",

  gd_back_title: "العودة إلى المعرض",
  gd_back_desc: "الرجوع إلى قائمة صورك.",

  gd_preview_title: "معاينة الصورة",
  gd_preview_desc:
    "هذا هو التصميم الذي سيُحوَّل إلى مسارات حفر.",

  gd_start_title: "بدء مشروع تشغيل رقمي",
  gd_start_desc:
    "الانتقال إلى إعداد المشروع: أبعاد الخشب وقطر الأداة، ثم توليد ملف G-Code.",

  gd_delete_title: "حذف الصورة",
  gd_delete_desc:
    "احذف هذه الصورة إذا لم تعد بحاجة إليها.",

  projects_new_title: "مشروع جديد",
  projects_new_desc:
    "ابدأ مشروعاً جديداً من صورة أو نمط مرفوع مسبقاً.",

  projects_view_title: "عرض المشروع",
  projects_view_desc:
    "فتح تفاصيل المشروع: الحالة، والمحاكاة، والتقرير، وملف G-Code.",

  projects_download_title: "تحميل G-Code",
  projects_download_desc:
    "تحميل ملف ‎.nc عندما تكون حالة المشروع «مكتمل».",

  projects_delete_title: "حذف المشروع",
  projects_delete_desc:
    "حذف المشروع نهائياً بعد التأكيد.",

  sim_upload_title: "رفع ملف G-Code",
  sim_upload_desc:
    "افتح النموذج لرفع ملف ‎.nc أو ‎.gcode، وتحديد أبعاد الخشب، ثم بدء المحاكاة ثلاثية الأبعاد.",

  sim_card_details_title: "فتح التفاصيل",
  sim_card_details_desc:
    "عرض معلومات الملف والمعاينة التفاعلية لمسار الأداة.",

  sim_card_download_title: "تحميل الملف",
  sim_card_download_desc:
    "تحميل ملف G-Code المرفوع إلى جهازك.",

  sim_card_delete_title: "حذف الملف المرفوع",
  sim_card_delete_desc:
    "حذف هذا الملف ومحاكاته بعد التأكيد.",

  sim_back_title: "العودة إلى القائمة",
  sim_back_desc:
    "الرجوع إلى جميع ملفات G-Code المرفوعة.",

  sim_preview_title: "معاينة مسار الأداة ثلاثية الأبعاد",
  sim_preview_desc:
    "تدوير المسار ومعاينته قبل استخدام الملف على الآلة.",

  sim_download_title: "تحميل G-Code",
  sim_download_desc:
    "تحميل ملف G-Code من صفحة التفاصيل.",

  sim_delete_title: "حذف",
  sim_delete_desc:
    "حذف هذا الملف ومحاكاته نهائياً.",

  settings_profile_title: "ملفك الشخصي",
  settings_profile_desc:
    "عرض اسم المستخدم، ومعرّف الحساب، والبريد الإلكتروني المرتبط.",

  settings_security_title: "الأمان",
  settings_security_desc:
    "غيّر كلمة المرور بإدخال الكلمة الحالية، ثم الكلمة الجديدة مرتين للتأكيد.",

  settings_save_title: "حفظ التغييرات",
  settings_save_desc:
    "تطبيق كلمة المرور الجديدة بعد تعبئة حقول الأمان.",
},
    },
  },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: "en",
    interpolation: {
      escapeValue: false,
    },
  });

document.documentElement.dir = i18n.language === "ar" ? "rtl" : "ltr";
document.documentElement.lang = i18n.language || "en";

i18n.on("languageChanged", (lng) => {
  document.documentElement.dir = lng === "ar" ? "rtl" : "ltr";
  document.documentElement.lang = lng;
});

export default i18n;
